import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useEffect, useState } from "react";
import { api } from "../api/axios";

type Candidate = {
  id: string;
  fullName: string;
  batch?: string;
  office: string;
};

export const BallotPage = () => {
  const navigate = useNavigate();
  const { electionId, token, isAuthReady } = useAuth();

  const [submitting, setSubmitting] = useState(false);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [president, setPresident] = useState("");
  const [secretary, setSecretary] = useState("");
  const [treasurer, setTreasurer] = useState("");

  useEffect(() => {
    if (!isAuthReady) return;

    if (!electionId || !token) {
      setLoading(false);
      setError("Session expired or not ready. Please log in again.");
      return;
    }

    const fetchBallot = async () => {
      try {
        // Check vote status
        const statusRes = await api.get(`/votes/status/${electionId}`);

        if (statusRes.data.hasVoted) {
          navigate("/success");
          return;
        }

        const res = await api.get(`/elections/${electionId}/ballot`);
        setCandidates(res.data.candidates);
      } catch (err) {
        const errorMessage =
          err instanceof Error ? err.message : "Failed to load ballot";
        setError(errorMessage);
        console.log(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    fetchBallot();
  }, [isAuthReady, electionId, token, navigate]);

  if (!isAuthReady) {
    return <div className="p-10">Preparing session...</div>;
  }
  if (loading) return <div className="p-10">Loading ballot...</div>;
  if (error) return <div className="p-10 text-red-500">{error}</div>;

  if (!electionId || !token) {
    return (
      <div className="p-10">
        Session not ready. Please wait or log in again.
      </div>
    );
  }

  const presidents = candidates.filter((c) => c.office === "President");
  const secretaries = candidates.filter((c) => c.office === "Secretary");
  const treasurers = candidates.filter((c) => c.office === "Treasurer");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!president || !secretary || !treasurer) {
      alert("Please select all 3 positions.");
      return;
    }

    if (
      president === secretary ||
      president === treasurer ||
      secretary === treasurer
    ) {
      alert("Please select 3 different candidates.");
      return;
    }

    setSubmitting(true);

    try {
      await api.post("/votes/submit", {
        electionId,
        presidentCandidateId: president,
        secretaryCandidateId: secretary,
        treasurerCandidateId: treasurer,
      });

      navigate("/success");
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Vote failed";
      alert(errorMessage);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <div className="min-h-screen bg-gray-100 flex justify-center py-10">
        <form
          onSubmit={handleSubmit}
          className="bg-white p-8 rounded shadow-md w-[600px]"
        >
          <h2 className="text-2xl font-bold mb-6 text-center">
            Cast Your Vote
          </h2>

          {/* President */}
          <div className="mb-6">
            <label className="font-semibold">President</label>
            <select
              value={president}
              onChange={(e) => setPresident(e.target.value)}
              className="w-full border p-2 rounded mt-2"
            >
              <option value="">Select candidate</option>
              {presidents.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.fullName} {c.batch ? `(${c.batch})` : ""}
                </option>
              ))}
            </select>
          </div>

          {/* Secretary */}
          <div className="mb-6">
            <label className="font-semibold">Secretary</label>
            <select
              value={secretary}
              onChange={(e) => setSecretary(e.target.value)}
              className="w-full border p-2 rounded mt-2"
            >
              <option value="">Select candidate</option>
              {secretaries.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.fullName} {c.batch ? `(${c.batch})` : ""}
                </option>
              ))}
            </select>
          </div>

          {/* Treasurer */}
          <div className="mb-6">
            <label className="font-semibold">Treasurer</label>
            <select
              value={treasurer}
              onChange={(e) => setTreasurer(e.target.value)}
              className="w-full border p-2 rounded mt-2"
            >
              <option value="">Select candidate</option>
              {treasurers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.fullName} {c.batch ? `(${c.batch})` : ""}
                </option>
              ))}
            </select>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-green-600 text-white py-3 rounded hover:bg-green-700"
          >
            Submit Vote
          </button>
        </form>
      </div>
    </>
  );
};
